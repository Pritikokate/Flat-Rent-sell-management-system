<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Navigation bar</title>
  <link rel="stylesheet" href="style.css">
  
</head>
<body>
  <nav>
    
        <div>
          
            <p> Admin Dashboard</p>

        </div>  
        <ul>
        <li>
            <a href="admin-dashboard.php"><b>Home</b></a>
          </li>
          <li>
            <a href="panel.php"><b>DASHBOARD</b></a>
          </li>
          <li>
          <li>
            <a href="district.php"><b>district</b></a>
          </li>
          <li>
            <a href="city.php"><b>city<b></a>
          </li>
          <li>
            <a href="addflat.php"><b>Add Flats<b></a>
          </li>
        
         
         

          <li>
          <select style="        font-family: var(--theme-ordinary-font);
        font-size: 25px;
        font-weight:bold;
        text-decoration: bold;
        height: 50px;
        border-color: transparent;
        line-height: 25px;
        padding-left: 40px;
        padding-right: 10px;
        padding-top:10px;
        background-color: transparent;
        
        color: white;
        border-radius: 3px 0px 0px 3px;" onchange="location=this.value;" name="type">
    
                   
                    
    
                    <option style="color:black"value=""><a>SERVICES</a></option>
                    <option style="color:black"value="addabout.php"><a>ADD ADVERTISEMENT</a></option>
                    <option style="color:black"value="aboutview.php"><a>VIEW ADVERTISEMENT</a></option>
                    <option style="color:black"value="usermanage.php"><a>MANAGE USER</a></option>
                    <option style="color:black"value="logout.php"><a>LOGOUT </a></option>
                                                                                          
              
                   
                                                                                          
                </select>
          </li>
        </ul>  




  </nav>
  <div class="content-items">
  <img src="images/rshmpg.jpg" alt="tfyguhij;k'l;">
  
    
  </div>
  </div>
</body>
</html>
